/* version.h
 *
 * Define the version string.
 */
#ifndef VERSION_H
#define VERSION_H

#define VERSION "1.0.0"

#endif

