#include <stdio.h>
#include "version.h"

int main(int argc, char *argv[])
{
    printf("Simple program v%s\n", VERSION);
    return 0;
}
